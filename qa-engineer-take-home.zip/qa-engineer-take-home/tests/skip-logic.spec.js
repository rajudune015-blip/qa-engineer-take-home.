const { test, expect } = require('@playwright/test');
const path = require('node:path');

test.beforeEach(async ({ page }) => {
  await page.goto('file://' + path.resolve(__dirname, '../fixtures/dynamic-survey.html'));
});

test('shows hobby text field when answer is Yes', async ({ page }) => {
  const hobby = page.getByRole('textbox', { name: 'What is your hobby?' });
  await expect(hobby).toBeHidden();

  await page.getByRole('radio', { name: 'Yes' }).check();
  await expect(hobby).toBeVisible();
  await expect(hobby).toHaveAttribute('required', '');
});

test('hides and clears hobby text field when answer changes to No', async ({ page }) => {
  const hobby = page.getByRole('textbox', { name: 'What is your hobby?' });
  await page.getByRole('radio', { name: 'Yes' }).check();
  await hobby.fill('Gardening');

  await page.getByRole('radio', { name: 'No' }).check();
  await expect(hobby).toBeHidden();
  await expect(hobby).toHaveValue('');
  await expect(hobby).not.toHaveAttribute('required', '');
});
