const { test, expect } = require('@playwright/test');

function payload(overrides = {}) {
  return {
    submissionId: 'sub-ankit-001',
    deviceId: 'device-ankit',
    localId: 'School_1',
    entityName: 'Govt Primary School',
    schemaVersion: 'v1',
    answers: { building_condition: 'Good' },
    capturedAt: '2026-10-14T10:00:00+05:30',
    ...overrides,
  };
}

test('accepts the same local ID from two different offline devices without overwriting', async ({ request }) => {
  const ankit = await request.post('/sync-survey', { data: payload() });
  expect(ankit.status()).toBe(201);
  expect(await ankit.json()).toMatchObject({ status: 'accepted', submissionId: 'sub-ankit-001' });

  const pooja = await request.post('/sync-survey', {
    data: payload({
      submissionId: 'sub-pooja-001',
      deviceId: 'device-pooja',
      answers: { building_condition: 'Needs repair' },
      capturedAt: '2026-10-14T11:00:00+05:30',
    }),
  });
  expect(pooja.status()).toBe(201);
  expect(await pooja.json()).toMatchObject({ status: 'accepted', submissionId: 'sub-pooja-001' });
});

test('retrying the identical submission is idempotent', async ({ request }) => {
  const body = payload({ submissionId: 'sub-retry-001', deviceId: 'device-retry' });
  const first = await request.post('/sync-survey', { data: body });
  const retry = await request.post('/sync-survey', { data: body });

  expect(first.status()).toBe(201);
  expect(retry.status()).toBe(200);
  expect(await retry.json()).toMatchObject({ status: 'already_accepted' });
});

test('rejects reuse of an idempotency key with a different payload', async ({ request }) => {
  const body = payload({ submissionId: 'sub-conflict-001', deviceId: 'device-conflict' });
  expect((await request.post('/sync-survey', { data: body })).status()).toBe(201);

  const changed = { ...body, answers: { building_condition: 'Poor' } };
  const response = await request.post('/sync-survey', { data: changed });
  expect(response.status()).toBe(409);
  expect(await response.json()).toMatchObject({ error: 'idempotency_conflict' });
});

test('rejects a missing device ID', async ({ request }) => {
  const body = payload({ submissionId: 'sub-invalid-001' });
  delete body.deviceId;
  const response = await request.post('/sync-survey', { data: body });
  expect(response.status()).toBe(400);
  expect(await response.json()).toMatchObject({ error: 'missing_required_field' });
});

test('same device/local ID cannot silently create a second submission', async ({ request }) => {
  const first = payload({ submissionId: 'sub-local-001', deviceId: 'device-same' });
  expect((await request.post('/sync-survey', { data: first })).status()).toBe(201);

  const duplicateLocal = { ...first, submissionId: 'sub-local-002', answers: { building_condition: 'Poor' } };
  const response = await request.post('/sync-survey', { data: duplicateLocal });
  expect(response.status()).toBe(409);
  expect(await response.json()).toMatchObject({ error: 'device_local_id_conflict' });
});
