const http = require('node:http');

const submissions = new Map();
const byDeviceLocalId = new Map();

function send(res, status, body) {
  res.writeHead(status, { 'content-type': 'application/json' });
  res.end(JSON.stringify(body));
}

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/health') {
    return send(res, 200, { status: 'ok' });
  }
  if (req.method !== 'POST' || req.url !== '/sync-survey') {
    return send(res, 404, { error: 'not_found' });
  }

  let raw = '';
  req.on('data', chunk => { raw += chunk; });
  req.on('end', () => {
    let body;
    try {
      body = JSON.parse(raw);
    } catch {
      return send(res, 400, { error: 'invalid_json' });
    }

    const required = ['submissionId', 'deviceId', 'localId', 'entityName', 'answers'];
    if (!body || required.some(key => body[key] === undefined || body[key] === null || body[key] === '')) {
      return send(res, 400, { error: 'missing_required_field' });
    }

    const existing = submissions.get(body.submissionId);
    if (existing) {
      if (JSON.stringify(existing) === JSON.stringify(body)) {
        return send(res, 200, { status: 'already_accepted', submissionId: body.submissionId });
      }
      return send(res, 409, { error: 'idempotency_conflict', submissionId: body.submissionId });
    }

    // A local ID is only unique within a device in this illustrative contract.
    // Different devices may legitimately both have localId "School_1".
    const deviceLocalKey = `${body.deviceId}::${body.localId}`;
    const sameDeviceLocal = byDeviceLocalId.get(deviceLocalKey);
    if (sameDeviceLocal && sameDeviceLocal !== body.submissionId) {
      return send(res, 409, { error: 'device_local_id_conflict', localId: body.localId });
    }

    submissions.set(body.submissionId, body);
    byDeviceLocalId.set(deviceLocalKey, body.submissionId);
    return send(res, 201, { status: 'accepted', submissionId: body.submissionId });
  });
});

server.listen(4173, '127.0.0.1', () => {
  console.log('Mock API listening on http://127.0.0.1:4173');
});
